# nircls — NIR Species Classification Toolkit

Instalação: `pip install -e .`
